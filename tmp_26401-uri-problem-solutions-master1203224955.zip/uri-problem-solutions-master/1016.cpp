#include <iostream>
#include <stdio.h>

int main(){
    
    int a;
    
    std::cin >> a;
    
    printf("%d minutos\n", (a*60)/30);
    return 0;
}
