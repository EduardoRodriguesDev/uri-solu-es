#include <iostream>
#include <stdio.h>

using namespace std;

int main(){
    int a, b;
    cin >> a;
    cin >> b;
    
    float f = (a*b)/12.0;
    
    printf("%.3f\n", f);
    
    return 0;
    
}
    
