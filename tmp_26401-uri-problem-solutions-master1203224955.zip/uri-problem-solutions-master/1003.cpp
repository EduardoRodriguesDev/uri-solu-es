#include <iostream>

using namespace std;

int main(){
    int a,b;
    
    cin >> a;
    cin >> b;
    
    cout << "SOMA = " << a+b << endl;
    return 0;
}
